#ifndef GOMERGE_H
#define GOMERGE_H

#include <iostream>
#include <fstream>

using namespace std;

void goMerge(string fil1, string fil2, string fil3);
    
#endif
