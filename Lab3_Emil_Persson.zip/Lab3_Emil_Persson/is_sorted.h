#ifndef IS_SORTED_H
#define IS_SORTED_H

#include <vector>
#include <iostream>
#include <fstream>

using namespace std;


bool isSorted(string FileName);

#endif
    